"""VREM dedicated desktop window."""
from __future__ import annotations

import argparse
import os
import socket
import sys
import threading
import time
import traceback
import urllib.request
from pathlib import Path

import webview
from waitress import create_server


BASE_DIR = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT_START = 5000
PORT_END = 5010


def find_free_port() -> int:
    requested = os.environ.get("VREM_PORT")
    if requested:
        try:
            ports = [int(requested)]
        except ValueError:
            ports = []
    else:
        ports = list(range(PORT_START, PORT_END + 1))
    for port in ports:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as candidate:
            candidate.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                candidate.bind((HOST, port))
            except OSError:
                continue
            return port
    raise RuntimeError("VREM could not find an open port from 5000 through 5010.")


def wait_for_server(url: str, timeout: float = 20.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(f"{url}/api/health", timeout=1.0) as response:
                if response.status == 200:
                    return
        except Exception:
            time.sleep(0.12)
    raise RuntimeError("VREM's local server did not become ready in time.")


class DesktopApi:
    def __init__(self) -> None:
        self.window: webview.Window | None = None
        self.maximized = False

    def minimize(self) -> None:
        if self.window:
            self.window.minimize()

    def toggle_maximize(self) -> bool:
        if not self.window:
            return False
        if self.maximized:
            self.window.restore()
            self.maximized = False
        else:
            self.window.maximize()
            self.maximized = True
        return self.maximized

    def close(self) -> None:
        if self.window:
            self.window.destroy()


class DesktopRuntime:
    def __init__(self) -> None:
        self.server = None
        self.server_thread: threading.Thread | None = None
        self.url = ""

    def start_server(self) -> None:
        port = find_free_port()
        os.environ["VREM_HOST"] = HOST
        os.environ["VREM_PORT"] = str(port)
        from app import app

        self.server = create_server(app, host=HOST, port=port, threads=8)
        self.server_thread = threading.Thread(
            target=self.server.run,
            name="VREM-local-server",
            daemon=True,
        )
        self.server_thread.start()
        self.url = f"http://localhost:{port}"
        wait_for_server(self.url)

    def stop_server(self, *_args) -> None:
        if self.server:
            try:
                self.server.close()
            except Exception:
                pass
        dispatcher = getattr(self.server, "task_dispatcher", None)
        if dispatcher:
            try:
                dispatcher.shutdown()
            except Exception:
                pass


def check_runtime() -> int:
    import tkinter

    print(f"VREM desktop dependencies ready. Tk {tkinter.TkVersion}; pywebview loaded.")
    return 0


def show_startup_error(message: str) -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        messagebox.showerror("VREM Windowed", message, parent=root)
        root.destroy()
    except Exception:
        pass


def run_desktop() -> int:
    runtime = DesktopRuntime()
    runtime.start_server()

    api = DesktopApi()
    window = webview.create_window(
        "VREM 0.6.1 Beta",
        runtime.url,
        js_api=api,
        width=1500,
        height=920,
        min_size=(980, 640),
        resizable=True,
        frameless=True,
        easy_drag=False,
        shadow=True,
        background_color="#050505",
        text_select=False,
        zoomable=False,
    )
    if window is None:
        runtime.stop_server()
        raise RuntimeError("VREM could not create its desktop window.")

    api.window = window
    window.events.maximized += lambda *_args: setattr(api, "maximized", True)
    window.events.restored += lambda *_args: setattr(api, "maximized", False)
    window.events.closed += runtime.stop_server

    gui = "edgechromium" if sys.platform.startswith("win") else "qt"
    icon_name = "vrem.ico" if sys.platform.startswith("win") else "vrem-logo.png"
    webview.start(
        gui=gui,
        debug=False,
        private_mode=False,
        storage_path=str(BASE_DIR / ".desktop-profile"),
        icon=str(BASE_DIR / "static" / icon_name),
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="VREM dedicated desktop window")
    parser.add_argument("--check", action="store_true", help="verify windowed runtime imports")
    args = parser.parse_args()
    if args.check:
        return check_runtime()
    return run_desktop()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as exc:
        error_log = BASE_DIR / ".cache" / "windowed-error.log"
        try:
            error_log.parent.mkdir(parents=True, exist_ok=True)
            error_log.write_text(traceback.format_exc(), encoding="utf-8")
        except Exception:
            pass
        show_startup_error(
            f"VREM Windowed could not start.\n\n{exc}\n\n"
            "Browser mode is still available from the launcher."
        )
        raise SystemExit(1)
