#!/usr/bin/env bash
set -euo pipefail

# VREM is a beta visualization and research tool. It is not an official weather warning system and must not be used to make life-safety decisions. Radar, weather, location, and alert data may be delayed, incomplete, inaccurate, or unavailable. Always rely on official sources such as the National Weather Service, NOAA Weather Radio, Wireless Emergency Alerts, and local emergency management for watches, warnings, and emergency instructions.
if [[ "${VREM_DISCLAIMER_SHOWN:-0}" != "1" ]]; then
  cat <<'DISCLAIMER'

 VREM is a beta visualization and research tool. It is not an official weather
 warning system and must not be used to make life-safety decisions. Radar,
 weather, location, and alert data may be delayed, incomplete, inaccurate, or
 unavailable. Always rely on official sources such as the National Weather
 Service, NOAA Weather Radio, Wireless Emergency Alerts, and local emergency
 management for watches, warnings, and emergency instructions.

DISCLAIMER
  if [[ -t 0 ]]; then
    read -r -p " Press Enter to continue."
    echo
  fi
  export VREM_DISCLAIMER_SHOWN=1
fi

exec bash "$(dirname "${BASH_SOURCE[0]}")/vrem_browser.sh" "$@"
