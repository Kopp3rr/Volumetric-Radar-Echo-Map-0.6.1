"""VREM launch mode selector."""
from __future__ import annotations

import os
import subprocess
import sys
import tkinter as tk
from tkinter import messagebox
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
IS_WINDOWS = sys.platform.startswith("win")
BG = "#050505"
PANEL = "#0b0b0d"
BORDER = "#2f2f31"
MAROON = "#542829"
ACCENT = "#ef4b4e"
ACCENT_SOFT = "#b33a3d"
TEXT = "#d8d8d8"
TEXT_2 = "#9f9a9a"
TEXT_3 = "#5f5758"
FONT = "Share Tech Mono"
HOVER_STEP_MS = 18
launch_started = False


def blend_color(start: str, end: str, amount: float) -> str:
    amount = max(0.0, min(1.0, amount))
    start_rgb = tuple(int(start[index:index + 2], 16) for index in (1, 3, 5))
    end_rgb = tuple(int(end[index:index + 2], 16) for index in (1, 3, 5))
    mixed = tuple(round(a + (b - a) * amount) for a, b in zip(start_rgb, end_rgb))
    return f"#{mixed[0]:02x}{mixed[1]:02x}{mixed[2]:02x}"


def _direct_launcher(mode: str) -> Path:
    if IS_WINDOWS:
        return BASE_DIR / ("VREM_Browser.bat" if mode == "browser" else "VREM_Windowed.bat")
    return BASE_DIR / ("vrem_browser.sh" if mode == "browser" else "vrem_windowed.sh")


def launch_mode(mode: str) -> None:
    global launch_started
    if launch_started:
        return
    launcher = _direct_launcher(mode)
    if not launcher.exists():
        raise FileNotFoundError(f"VREM launcher was not found: {launcher}")
    launch_started = True
    try:
        if IS_WINDOWS:
            creation_flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
            subprocess.Popen(
                ["cmd.exe", "/c", str(launcher)],
                cwd=BASE_DIR,
                creationflags=creation_flags,
            )
        else:
            subprocess.Popen(["bash", str(launcher)], cwd=BASE_DIR, start_new_session=True)
    except Exception as exc:
        launch_started = False
        messagebox.showerror("VREM Launcher", f"VREM could not start.\n\n{exc}", parent=root)
        return
    root.after(40, root.destroy)


def add_option(parent: tk.Widget, mode: str, title: str, meta: str, status: str, column: int) -> None:
    card_width = 266
    card_height = 182
    mode_code = "01 // WEB" if mode == "browser" else "02 // APP"
    button = tk.Canvas(
        parent,
        width=card_width,
        height=card_height,
        bg=PANEL,
        borderwidth=0,
        highlightthickness=0,
        cursor="hand2",
        takefocus=True,
    )
    button.grid(row=0, column=column, sticky="nsew", padx=(0, 6) if column == 0 else (6, 0))

    surface_id = button.create_rectangle(
        1,
        1,
        card_width - 2,
        card_height - 2,
        fill=PANEL,
        outline="",
    )
    border_id = button.create_rectangle(
        0,
        0,
        card_width - 1,
        card_height - 1,
        outline=BORDER,
        width=1,
    )
    stripe_id = button.create_rectangle(0, 0, 3, card_height, fill=ACCENT_SOFT, outline="")
    inner_border_id = button.create_rectangle(
        6,
        6,
        card_width - 7,
        card_height - 7,
        outline="#161617",
        width=1,
    )
    button.create_line(22, 43, card_width - 21, 43, fill="#262225", width=1)
    button.create_line(22, 130, card_width - 21, 130, fill="#1f1d1e", width=1)
    corner_tl_h = button.create_line(9, 9, 24, 9, fill=MAROON, width=1)
    corner_tl_v = button.create_line(9, 9, 9, 22, fill=MAROON, width=1)
    corner_br_h = button.create_line(
        card_width - 24,
        card_height - 9,
        card_width - 9,
        card_height - 9,
        fill=MAROON,
        width=1,
    )
    corner_br_v = button.create_line(
        card_width - 9,
        card_height - 22,
        card_width - 9,
        card_height - 9,
        fill=MAROON,
        width=1,
    )
    status_id = button.create_text(
        22,
        20,
        text=status,
        fill=ACCENT,
        font=(FONT, 8),
        anchor="nw",
    )
    mode_id = button.create_text(
        card_width - 21,
        20,
        text=mode_code,
        fill=TEXT_3,
        font=(FONT, 7),
        anchor="ne",
    )
    title_id = button.create_text(
        22,
        57,
        text=title,
        fill=TEXT,
        font=(FONT, 17),
        anchor="nw",
    )
    detail_id = button.create_text(
        22,
        91,
        text=meta,
        fill=TEXT_2,
        font=(FONT, 9),
        anchor="nw",
        width=210,
    )
    action_box_id = button.create_rectangle(
        card_width - 100,
        card_height - 40,
        card_width - 18,
        card_height - 13,
        fill="#0b0b0d",
        outline=MAROON,
        width=1,
    )
    action_id = button.create_text(
        card_width - 26,
        card_height - 26,
        text="LAUNCH >",
        fill=ACCENT_SOFT,
        font=(FONT, 8),
        anchor="e",
    )
    ready_id = button.create_text(
        22,
        card_height - 26,
        text="READY",
        fill=TEXT_3,
        font=(FONT, 7),
        anchor="w",
    )
    animation = {
        "value": 0.0,
        "target": 0.0,
        "job": None,
        "armed": False,
    }

    def render_hover(value: float) -> None:
        border = blend_color(BORDER, ACCENT, value)
        stripe = blend_color(ACCENT_SOFT, ACCENT, value)
        surface = blend_color(PANEL, "#13090a", value * 0.38)
        inner_border = blend_color("#161617", MAROON, value * 0.42)
        title_color = blend_color(TEXT, "#ffffff", value * 0.35)
        action_color = blend_color(ACCENT_SOFT, ACCENT, value)
        muted_red = blend_color(MAROON, ACCENT_SOFT, value)
        ready_color = blend_color(TEXT_3, ACCENT, value)
        button.itemconfigure(surface_id, fill=surface)
        button.itemconfigure(border_id, outline=border, width=1)
        button.itemconfigure(stripe_id, fill=stripe)
        button.itemconfigure(inner_border_id, outline=inner_border)
        button.itemconfigure(title_id, fill=title_color)
        button.itemconfigure(action_id, fill=action_color)
        button.itemconfigure(action_box_id, outline=muted_red)
        button.itemconfigure(ready_id, fill=ready_color)
        for corner_id in (corner_tl_h, corner_tl_v, corner_br_h, corner_br_v):
            button.itemconfigure(corner_id, fill=muted_red)

    def animate_hover() -> None:
        animation["job"] = None
        current = animation["value"]
        target = animation["target"]
        if abs(target - current) < 0.01:
            animation["value"] = target
            render_hover(target)
            return
        animation["value"] = current + (target - current) / 3.2
        render_hover(animation["value"])
        animation["job"] = button.after(HOVER_STEP_MS, animate_hover)

    def set_hover(active: bool) -> None:
        animation["target"] = 1.0 if active else 0.0
        if animation["job"] is None:
            animation["job"] = button.after(HOVER_STEP_MS, animate_hover)

    def activate(_event: tk.Event | None = None) -> None:
        if animation["armed"] or launch_started:
            return
        animation["armed"] = True
        button.itemconfigure(surface_id, fill="#2a0c0e")
        button.itemconfigure(border_id, outline=ACCENT, width=2)
        button.itemconfigure(action_box_id, fill=ACCENT, outline=ACCENT)
        button.itemconfigure(action_id, text="ARMED", fill=BG)
        button.itemconfigure(ready_id, text="EXECUTING", fill=ACCENT)
        button.after(110, lambda: launch_mode(mode))

    button.bind("<Enter>", lambda _event: set_hover(True))
    button.bind("<Leave>", lambda _event: set_hover(False))
    button.bind("<FocusIn>", lambda _event: set_hover(True))
    button.bind("<FocusOut>", lambda _event: set_hover(False))
    button.bind("<ButtonRelease-1>", activate)
    button.bind("<Return>", activate)
    button.bind("<space>", activate)


root = tk.Tk()
root.title("VREM Launcher")
root.configure(bg=BG)
root.overrideredirect(True)
root.attributes("-topmost", True)
root.resizable(False, False)

window_width = 590
window_height = 360
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = max(0, (screen_width - window_width) // 2)
y = max(0, (screen_height - window_height) // 2)
root.geometry(f"{window_width}x{window_height}+{x}+{y}")

shell = tk.Frame(root, bg=BG, highlightbackground=MAROON, highlightthickness=1)
shell.pack(fill="both", expand=True)

top = tk.Frame(shell, bg=BG, height=56)
top.pack(fill="x")
top.pack_propagate(False)
logo_image = tk.PhotoImage(file=str(BASE_DIR / "static" / "vrem-logo.png")).subsample(11, 11)
tk.Label(top, image=logo_image, bg=BG).pack(side="left", padx=(18, 14))
tk.Label(top, text="BETA 0.6.1", bg=BG, fg=TEXT_3, font=(FONT, 8)).pack(side="left")
tk.Label(top, text="LAUNCHER", bg=BG, fg=TEXT_2, font=(FONT, 10)).pack(side="left", padx=28)

close_button = tk.Label(
    top,
    text="X",
    bg=BG,
    fg=TEXT_2,
    font=(FONT, 11),
    width=4,
    cursor="hand2",
)
close_button.pack(side="right", fill="y")
close_button.bind("<Enter>", lambda _event: close_button.configure(bg=ACCENT, fg=BG))
close_button.bind("<Leave>", lambda _event: close_button.configure(bg=BG, fg=TEXT_2))
close_button.bind("<Button-1>", lambda _event: root.destroy())

tk.Frame(shell, bg=ACCENT, height=2).pack(fill="x")

intro = tk.Frame(shell, bg=BG, padx=18, pady=15)
intro.pack(fill="x")
tk.Label(
    intro,
    text="SELECT RUNTIME",
    bg=BG,
    fg=TEXT_3,
    font=(FONT, 8),
    anchor="w",
).pack(fill="x")
tk.Label(
    intro,
    text="Both modes use the same live local VREM server.",
    bg=BG,
    fg=TEXT_2,
    font=(FONT, 9),
    anchor="w",
).pack(fill="x", pady=(5, 0))

options = tk.Frame(shell, bg=BG, padx=18)
options.pack(fill="both", expand=True)
options.grid_columnconfigure(0, weight=1)
options.grid_columnconfigure(1, weight=1)
add_option(options, "browser", "BROWSER", "Open VREM in your default browser.", "STANDARD WEB RUNTIME", 0)
add_option(options, "windowed", "WINDOWED", "Open VREM in its dedicated desktop shell.", "CUSTOM APP RUNTIME", 1)

footer = tk.Frame(shell, bg=BG, padx=18, pady=10)
footer.pack(fill="x")
tk.Label(
    footer,
    text="ESC  CLOSE",
    bg=BG,
    fg=TEXT_3,
    font=(FONT, 8),
).pack(side="right")

root.bind("<Escape>", lambda _event: root.destroy())
root.mainloop()
