@echo off
setlocal EnableExtensions
title VREM 0.6.1 Beta - Browser
color 0C

rem VREM is a beta visualization and research tool. It is not an official weather warning system and must not be used to make life-safety decisions. Radar, weather, location, and alert data may be delayed, incomplete, inaccurate, or unavailable. Always rely on official sources such as the National Weather Service, NOAA Weather Radio, Wireless Emergency Alerts, and local emergency management for watches, warnings, and emergency instructions.
if not defined VREM_DISCLAIMER_SHOWN (
    echo.
    echo  VREM is a beta visualization and research tool. It is not an official
    echo  weather warning system and must not be used to make life-safety decisions.
    echo  Radar, weather, location, and alert data may be delayed, incomplete,
    echo  inaccurate, or unavailable. Always rely on official sources such as the
    echo  National Weather Service, NOAA Weather Radio, Wireless Emergency Alerts,
    echo  and local emergency management for watches, warnings, and emergency
    echo  instructions.
    echo.
    echo  Press any key to continue.
    pause >nul
    set "VREM_DISCLAIMER_SHOWN=1"
)

cd /d "%~dp0"

echo.
echo  VREM 0.6.1 Beta
echo  Browser Edition
echo  -------------------------------------------------------
echo.

where python >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python was not found on PATH.
    echo  Install Python 3.11+ from python.org and enable "Add python.exe to PATH".
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo  Creating local Python environment...
    python -m venv .venv
    if errorlevel 1 (
        echo  [ERROR] Could not create the local Python environment.
        pause
        exit /b 1
    )
)

echo  Installing/verifying browser dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
".venv\Scripts\python.exe" -m pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo  [ERROR] Dependency installation failed.
    pause
    exit /b 1
)

for /f %%P in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "5000..5010 | Where-Object { -not (Get-NetTCPConnection -LocalPort $_ -State Listen -ErrorAction SilentlyContinue) } | Select-Object -First 1"') do set VREM_PORT=%%P
if "%VREM_PORT%"=="" set VREM_PORT=5000

set VREM_HOST=127.0.0.1
set VREM_ENV=production
set VREM_MAX_SCANS=32
set VREM_MAX_LIVE_GATES=65000
set VREM_MAX_CACHE_FILES=96

echo.
echo  Starting VREM Browser at http://localhost:%VREM_PORT%
echo  Close this window to stop the server.
echo  -------------------------------------------------------
echo.

start "" "http://localhost:%VREM_PORT%"
".venv\Scripts\python.exe" app.py

pause
