#!/usr/bin/env bash
set -euo pipefail

# VREM is a beta visualization and research tool. It is not an official weather warning system and must not be used to make life-safety decisions. Radar, weather, location, and alert data may be delayed, incomplete, inaccurate, or unavailable. Always rely on official sources such as the National Weather Service, NOAA Weather Radio, Wireless Emergency Alerts, and local emergency management for watches, warnings, and emergency instructions.
if [[ "${VREM_DISCLAIMER_SHOWN:-0}" != "1" ]]; then
  cat <<'DISCLAIMER'

 VREM is a beta visualization and research tool. It is not an official weather
 warning system and must not be used to make life-safety decisions. Radar,
 weather, location, and alert data may be delayed, incomplete, inaccurate, or
 unavailable. Always rely on official sources such as the National Weather
 Service, NOAA Weather Radio, Wireless Emergency Alerts, and local emergency
 management for watches, warnings, and emergency instructions.

DISCLAIMER
  if [[ -t 0 ]]; then
    read -r -p " Press Enter to continue."
    echo
  fi
  export VREM_DISCLAIMER_SHOWN=1
fi

cd "$(dirname "${BASH_SOURCE[0]}")"

find_free_port() {
  local port
  for port in {5000..5010}; do
    if command -v ss >/dev/null 2>&1; then
      if ! ss -ltn | awk '{print $4}' | grep -Eq "[:.]${port}$"; then
        echo "$port"
        return 0
      fi
    elif command -v lsof >/dev/null 2>&1; then
      if ! lsof -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1; then
        echo "$port"
        return 0
      fi
    else
      echo "$port"
      return 0
    fi
  done
  echo "5000"
}

echo
echo " VREM 0.6.1 Beta"
echo " Browser Edition"
echo " -------------------------------------------------------"
echo

PYTHON_BIN="${PYTHON_BIN:-python3}"
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo " [ERROR] python3 was not found on PATH."
  exit 1
fi

if [ ! -x ".venv/bin/python" ]; then
  echo " Creating local Python environment..."
  if ! "$PYTHON_BIN" -m venv .venv; then
    echo " [ERROR] Could not create the local Python environment."
    echo " On Ubuntu/Debian, install python3-venv, then run this script again."
    exit 1
  fi
fi

echo " Installing/verifying browser dependencies..."
".venv/bin/python" -m pip install --upgrade pip --quiet
".venv/bin/python" -m pip install -r requirements.txt --quiet

export VREM_HOST="${VREM_HOST:-127.0.0.1}"
export VREM_PORT="${VREM_PORT:-$(find_free_port)}"
export VREM_ENV="${VREM_ENV:-production}"
export VREM_MAX_SCANS="${VREM_MAX_SCANS:-32}"
export VREM_MAX_LIVE_GATES="${VREM_MAX_LIVE_GATES:-65000}"
export VREM_MAX_CACHE_FILES="${VREM_MAX_CACHE_FILES:-96}"

URL="http://localhost:${VREM_PORT}"
echo
echo " Starting VREM Browser at ${URL}"
echo " Press Ctrl+C to stop the server."
echo " -------------------------------------------------------"
echo

if command -v open >/dev/null 2>&1; then
  open "$URL" >/dev/null 2>&1 &
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$URL" >/dev/null 2>&1 &
fi

exec ".venv/bin/python" app.py
