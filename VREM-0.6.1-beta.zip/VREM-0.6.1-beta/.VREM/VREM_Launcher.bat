@echo off
setlocal EnableExtensions
title VREM 0.6.1 Beta - Launcher
color 0C

rem VREM is a beta visualization and research tool. It is not an official weather warning system and must not be used to make life-safety decisions. Radar, weather, location, and alert data may be delayed, incomplete, inaccurate, or unavailable. Always rely on official sources such as the National Weather Service, NOAA Weather Radio, Wireless Emergency Alerts, and local emergency management for watches, warnings, and emergency instructions.
if not defined VREM_DISCLAIMER_SHOWN (
    echo.
    echo  VREM is a beta visualization and research tool. It is not an official
    echo  weather warning system and must not be used to make life-safety decisions.
    echo  Radar, weather, location, and alert data may be delayed, incomplete,
    echo  inaccurate, or unavailable. Always rely on official sources such as the
    echo  National Weather Service, NOAA Weather Radio, Wireless Emergency Alerts,
    echo  and local emergency management for watches, warnings, and emergency
    echo  instructions.
    echo.
    echo  Press any key to continue.
    pause >nul
    set "VREM_DISCLAIMER_SHOWN=1"
)

cd /d "%~dp0"

where python >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [ERROR] Python was not found on PATH.
    echo  Install Python 3.11+ from python.org and enable "Add python.exe to PATH".
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo  Preparing VREM launcher...
    python -m venv .venv
    if errorlevel 1 (
        echo  [ERROR] Could not create the local Python environment.
        pause
        exit /b 1
    )
)

start "" ".venv\Scripts\pythonw.exe" launcher.py
exit /b 0
