#!/usr/bin/env bash
set -euo pipefail

# VREM is a beta visualization and research tool. It is not an official weather warning system and must not be used to make life-safety decisions. Radar, weather, location, and alert data may be delayed, incomplete, inaccurate, or unavailable. Always rely on official sources such as the National Weather Service, NOAA Weather Radio, Wireless Emergency Alerts, and local emergency management for watches, warnings, and emergency instructions.
if [[ "${VREM_DISCLAIMER_SHOWN:-0}" != "1" ]]; then
  cat <<'DISCLAIMER'

 VREM is a beta visualization and research tool. It is not an official weather
 warning system and must not be used to make life-safety decisions. Radar,
 weather, location, and alert data may be delayed, incomplete, inaccurate, or
 unavailable. Always rely on official sources such as the National Weather
 Service, NOAA Weather Radio, Wireless Emergency Alerts, and local emergency
 management for watches, warnings, and emergency instructions.

DISCLAIMER
  if [[ -t 0 ]]; then
    read -r -p " Press Enter to continue."
    echo
  fi
  export VREM_DISCLAIMER_SHOWN=1
fi

cd "$(dirname "${BASH_SOURCE[0]}")"

PYTHON_BIN="${PYTHON_BIN:-python3}"
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo " [ERROR] python3 was not found on PATH."
  exit 1
fi

if ! "$PYTHON_BIN" -c "import tkinter" >/dev/null 2>&1; then
  echo " [ERROR] Python Tkinter is required for the VREM mode picker."
  echo " On Ubuntu/Debian, install python3-tk and run this launcher again."
  exit 1
fi

if [ ! -x ".venv/bin/python" ]; then
  echo " Preparing VREM launcher..."
  if ! "$PYTHON_BIN" -m venv .venv; then
    echo " [ERROR] Could not create the local Python environment."
    echo " On Ubuntu/Debian, install python3-venv, then run this launcher again."
    exit 1
  fi
fi

exec ".venv/bin/python" launcher.py
